import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Viktor2 extends StationaryDuelingAlgorithm {
	
	private final int C;
	private int t;
	private int[][] winDif;
	private int[][] pairsPlayed;
	private int firstArm;
	private int secondArm;
	private int[] armsBeaten;
	private final Random random = new Random();
	private int[] played;
	
	public Viktor2(int K, int C) {
		super(K);
		this.C = C; 
	}

	@Override
	public void initialize() {
		t = 1;
		winDif = new int[K][K];
		pairsPlayed = new int[K][K];
		armsBeaten = new int[K];
		played = new int[K];
	}

	@Override
	public int[] getPair() {
		int pair[] = new int[2];
		if (t <= C * K * (K-1) / 2) {
			for (int i = 0; i < K-1; i++) {
				for (int j = i+1; j < K; j++) {
					if (pairsPlayed[i][j] < C) {
						pairsPlayed[i][j]++;
						firstArm = i;
						secondArm = j;
						pair[0] = firstArm;
						pair[1] = secondArm;
						return pair;
					}
				}
			}
			return pair;
		} else {
			int winner = getEmpericalCopelandWinner();
			int other = winner == 0 ? 1 : 0;
			for (int i = 1; i < K; i++) {
				if (i != winner && played[i] < played[other])
					other = i;
			}
			firstArm = Math.min(winner, other);
			secondArm = Math.max(winner, other);
			pair[0] = firstArm;
			pair[1] = secondArm;
			return pair;
		}
	}

	@Override
	public void update(boolean firstWon) {
		t++;
		played[firstArm]++;
		played[secondArm]++;
		if (firstWon) {
			winDif[firstArm][secondArm]++;
			if (winDif[firstArm][secondArm] == 1) 
				armsBeaten[firstArm]++;
			else if (winDif[firstArm][secondArm] == 0) 
				armsBeaten[secondArm]--;
		}
		else {
			winDif[firstArm][secondArm]--;
			if (winDif[firstArm][secondArm] == 0)
				armsBeaten[firstArm]--;
			else if (winDif[firstArm][secondArm] == -1)
				armsBeaten[secondArm]++;
		}
	}

	@Override
	public String toString() {
		return "Vik2";
	}

	@Override
	public int getSuspectedCondorcetWinner() {
		return getEmpericalCopelandWinner();
	}
	
	private int getEmpericalCopelandWinner() {
		int maxBeaten = armsBeaten[0];
		for (int i = 1; i < K; i++)
			maxBeaten = Math.max(maxBeaten, armsBeaten[i]);
		
		List<Integer> arms = new ArrayList<Integer>();
		for (int i = 0; i < K; i++) {
			if (armsBeaten[i] == maxBeaten) 
				arms.add(i);
		}
		
		return arms.get(random.nextInt(arms.size()));
	}
	
	@Override
	public void update(int winner, int loser) {}
}